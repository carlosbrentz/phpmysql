</div>

<footer>
	<div class="container">
 		©2018 DogCursos - Todos os direitos reservados.
 	</div>
</footer>
</body>
</html>