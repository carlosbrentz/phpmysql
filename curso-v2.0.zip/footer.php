</div>

<footer>
	<div class="container">
 		©2018 DogCursos - Todos os direitos reservados.
 	</div>

 	<script src="js/jquery.js"></script>
 	<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

 	<script>
 		
 		$(document).ready( function () {
		    $('#cursos').DataTable();
		    $('#alunos').DataTable();
		    $('#matriculas').DataTable();
		} );
 	</script>

</footer>
</body>
</html>